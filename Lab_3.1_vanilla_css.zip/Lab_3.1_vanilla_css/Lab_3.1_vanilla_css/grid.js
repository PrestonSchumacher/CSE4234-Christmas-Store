class Grid{
    constructor(numberOfColumns, numberOfRows, cards, gridStyle,cardsStyle){
    this.numberOfColumns = numberOfColumns;
    this.numberOfRows = numberOfRows;
    this.cards = cards;
    this.gridStyle = gridStyle;
    this.cardStyle = cardsStyle;
}
}
export default Grid;